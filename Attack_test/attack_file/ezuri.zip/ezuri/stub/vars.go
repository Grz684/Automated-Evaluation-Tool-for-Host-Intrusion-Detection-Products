// Code generated automatically; DO NOT EDIT.
// Generated using data from user input
package main

var (
	key      = "HM1dut%TPZ0fjRNRCk%LtpJBtwSGNACQ"
	iv       = "vnr4WPX0ZFu7TgDq"
	procName = "DEMON"
)
